package com.mobdeve.s17.deguzman.langelo.exercise1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class MainActivity extends AppCompatActivity {
    FloatingActionButton favorite;
    Drawable heart_filled;
    Drawable heart_blank;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        favorite = (FloatingActionButton) findViewById(R.id.favorite);
        heart_filled = getResources().getDrawable(R.drawable.heart_filled);
        heart_blank = getResources().getDrawable(R.drawable.heart_blank);
        favorite.setImageDrawable(heart_blank);
    }
    public void clickedFavorite(View v){
        Drawable current = favorite.getDrawable();
        if (current == heart_blank) {
            favorite.setImageDrawable(heart_filled);
        } else if (current == heart_filled) {
            favorite.setImageDrawable(heart_blank);
        }
    }
}