package com.example.fragmentsapplication;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.androdocs.httprequest.HttpRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class FragmentOne extends Fragment {

    View view;

    String CITY = "manila,ph";
    String API = "52877f60fe2f5f331ec8fb3b0c2d53b7";

    TextView addressTxt, updated_atTxt, statusTxt, tempTxt, temp_minTxt, temp_maxTxt, sunriseTxt,
            sunsetTxt, windTxt, pressureTxt, humidityTxt;

    public FragmentOne() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_fragment_one, container, false);

        addressTxt = view.findViewById(R.id.address);
        updated_atTxt = view.findViewById(R.id.updated_at);
        statusTxt = view.findViewById(R.id.status);
        tempTxt = view.findViewById(R.id.temp);
        temp_minTxt = view.findViewById(R.id.temp_min);
        temp_maxTxt = view.findViewById(R.id.temp_max);
        sunriseTxt = view.findViewById(R.id.sunrise);
        sunsetTxt = view.findViewById(R.id.sunset);
        windTxt = view.findViewById(R.id.wind);
        pressureTxt = view.findViewById(R.id.pressure);
        humidityTxt = view.findViewById(R.id.humidity);

//        humidityTxt.setText("Hello World");
//        addressTxt.setText("Hello World");

        new weatherTask().execute();

        return view;
    }

    class weatherTask extends AsyncTask<String, Void, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            /* Showing the ProgressBar, Making the main design GONE */
            view.findViewById(R.id.loader).setVisibility(View.VISIBLE);
            view.findViewById(R.id.mainContainer).setVisibility(View.GONE);
            view.findViewById(R.id.errorText).setVisibility(View.GONE);
        }

        protected String doInBackground(String... args) {
            String response = HttpRequest.excuteGet("https://api.openweathermap.org/data/2.5/weather?q=" + CITY + "&units=metric&appid=" + API);
            System.out.println("\n" + response + "\n\n");
            return response;
        }

        @Override
        protected void onPostExecute(String result) {

            System.out.println("\nin post execute");
            System.out.println(result + "\n\n");

            // Parse string to JSON object
            JSONObject json;
            try {
                json = new JSONObject(result);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            // Display temperature in "°C"
            try {
                // Modify UI contents
                // https://openweathermap.org/current

                String city = json.getString("name");
                addressTxt.setText(city);

                String updatedAt = json.getString("dt");
                Date date = new Date(Long.parseLong(updatedAt) * 1000);
                DateFormat format = new SimpleDateFormat("MMM dd yyyy, KK:mm a");
                format.setTimeZone(TimeZone.getTimeZone("Asia/Manila"));
                String formatted = format.format(date);
                updated_atTxt.setText(formatted);

                String weatherDescription = json.getJSONArray("weather").getJSONObject(0).getString("description");
//                weatherDescription = WordUtils.capitalize(weatherDescription);  // TODO: Capitalize first letter of each word
                statusTxt.setText(weatherDescription);

                String temp = Math.round(json.getJSONObject("main").getDouble("temp")) + "°C";
                tempTxt.setText(temp);

                String tempMin = "Min Temp: " + Math.round(json.getJSONObject("main").getDouble("temp_min")) + "°C";
                temp_minTxt.setText(tempMin);

                String tempMax = "Max Temp: " + Math.round(json.getJSONObject("main").getDouble("temp_max")) + "°C";
                temp_maxTxt.setText(tempMax);

                String sunrise = json.getJSONObject("sys").getString("sunrise");
                date = new Date(Long.parseLong(sunrise) * 1000);
                format = new SimpleDateFormat("K:mm a");
                format.setTimeZone(TimeZone.getTimeZone("Asia/Manila"));
                formatted = format.format(date);
                sunriseTxt.setText(formatted);

                String sunset = json.getJSONObject("sys").getString("sunset");
                date = new Date(Long.parseLong(sunset) * 1000);
                format = new SimpleDateFormat("K:mm a");
                format.setTimeZone(TimeZone.getTimeZone("Asia/Manila"));
                formatted = format.format(date);
                sunsetTxt.setText(formatted);

                // TODO: Add direction
                String wind = json.getJSONObject("wind").getString("speed");
                wind = String.valueOf(Math.round(Double.parseDouble(wind) * 3.6));  // Convert m/s to km/h
                windTxt.setText(wind + " km/h");

                String pressure = json.getJSONObject("main").getString("pressure") + " hPa";
                pressureTxt.setText(pressure);

                String humidity = json.getJSONObject("main").getString("humidity") + "%";
                humidityTxt.setText(humidity);

                // Make them visible
                view.findViewById(R.id.loader).setVisibility(View.GONE);
                view.findViewById(R.id.mainContainer).setVisibility(View.VISIBLE);
            } catch (Exception e) {
                view.findViewById(R.id.loader).setVisibility(View.GONE);
                view.findViewById(R.id.errorText).setVisibility(View.VISIBLE);
            }

        }
    }
}
