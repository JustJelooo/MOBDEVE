package com.mobdeve.s17.deguzman.langelo.modelingactivity;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

public class UserInputs extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private EditText firstName;
    private EditText lastName;
    private String gender;
    private EditText height;
    private EditText weight;
    private EditText contactNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        this.firstName = (EditText) findViewById(R.id.firstName);
        this.lastName = (EditText) findViewById(R.id.lastName);
        Spinner genderSpinner = findViewById(R.id.gender);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.genders, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genderSpinner.setAdapter(adapter);
        genderSpinner.setOnItemSelectedListener(this);
        this.height = (EditText) findViewById(R.id.height);
        this.weight = (EditText) findViewById(R.id.weight);
        this.contactNo = (EditText) findViewById(R.id.contactNo);
    }

    public void onClear(View v) {
        this.firstName.getText().clear();
        this.lastName.getText().clear();
        this.height.getText().clear();
        this.weight.getText().clear();
        this.contactNo.getText().clear();
    }

    public void onSubmit(View v) {
        Intent i = new Intent(this, Verdict.class);
        float meters = Float.parseFloat(this.height.getText().toString()) / 100;
        float bmi = Float.parseFloat(this.weight.getText().toString()) / (meters * meters);
        bmi = Math.round(bmi * 10) / 10.0f;
        i.putExtra("firstName", this.firstName.getText().toString());
        i.putExtra("height", this.height.getText().toString());
        i.putExtra("weight", this.weight.getText().toString());
        i.putExtra("gender", gender);
        i.putExtra("bmi", bmi);
        i.putExtra("contactNo", this.contactNo.getText().toString());
        startActivity(i);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View v, int i, long l) {
        gender = adapterView.getItemAtPosition(i).toString();
    }

    @Override
    public void onNothingSelected(AdapterView adapterView) {
        gender = "Male";
    }
}
