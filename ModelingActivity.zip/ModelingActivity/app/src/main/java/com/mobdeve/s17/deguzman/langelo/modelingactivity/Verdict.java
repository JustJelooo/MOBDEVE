package com.mobdeve.s17.deguzman.langelo.modelingactivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Verdict extends AppCompatActivity {

    private boolean isApproved = false;
    private final int Approved = R.drawable.accepted;
    private final int Waitlisted = R.drawable.waitlisted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decision);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            determineVerdict(extras);
            renderVerdict(extras);
        }
    }

    private void determineVerdict(Bundle extras) {
        String gender = extras.getString("gender");
        String height = extras.getString("height");
        float bmi = extras.getFloat("bmi");

        assert gender != null;
        if (gender.equals("Male")) {
            isApproved = (bmi >= 20f && bmi <= 24f && Integer.parseInt(height) >= 170);
        } else {
            isApproved = (bmi >= 19f && bmi <= 23f && Integer.parseInt(height) >= 160);
        }
    }

    private void renderVerdict(Bundle extras) {
        TextView header = findViewById(R.id.decisionHeader);
        ImageView expression = findViewById(R.id.image_memez);
        TextView verdict = findViewById(R.id.verdict);
        TextView height = findViewById(R.id.fin_height);
        TextView weight = findViewById(R.id.fin_weight);
        TextView gender = findViewById(R.id.fin_gender);
        TextView bmiOrContactNo = findViewById(R.id.bmiOrContactNo);

        header.setText("Thanks for applying, " + extras.getString("firstName") + "!");
        expression.setImageResource(isApproved ? Approved : Waitlisted);
        verdict.setText(isApproved ? "You Qualify!" : "I will get in touch with your contact no.");
        height.setText("Your height: " + extras.getString("height") + " cm");
        weight.setText("Your weight: " + extras.getString("weight") + " kg");
        gender.setText("Your assigned sex: " + extras.getString("gender"));
        bmiOrContactNo.setText(isApproved ? "Calculated BMI: " + extras.getFloat("bmi") :
                "Your contact no.: " + extras.getString("contactNo"));
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}
