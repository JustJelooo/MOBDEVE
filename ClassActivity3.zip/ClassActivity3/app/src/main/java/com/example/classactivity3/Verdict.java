package com.example.classactivity3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Verdict extends AppCompatActivity {

    private boolean isApproved = false;
    private final int TAKAMAKI_APPROVED = R.drawable.p1_approved;
    private final int TAKAMAKI_WAITLISTED = R.drawable.p1_wait;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verdict);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            determineVerdict(extras);
            renderVerdict(extras);
        }
    }

    private void determineVerdict(Bundle extras) {
        String gender = extras.getString("gender");
        String height = extras.getString("height");
        float bmi = extras.getFloat("bmi");

        assert gender != null;
        if (gender.equals("Male")) {
            isApproved = (bmi >= 20f && bmi <= 24f && Integer.parseInt(height) >= 170);
        } else {
            isApproved = (bmi >= 19f && bmi <= 23f && Integer.parseInt(height) >= 160);
        }
    }

    private void renderVerdict(Bundle extras) {
        TextView header = findViewById(R.id.tv_verdictHeader);
        ImageView expression = findViewById(R.id.imgv_expression);
        TextView verdict = findViewById(R.id.tv_verdict);
        TextView height = findViewById(R.id.tv_height);
        TextView weight = findViewById(R.id.tv_weight);
        TextView gender = findViewById(R.id.tv_gender);
        TextView bmiOrContactNo = findViewById(R.id.tv_bmiOrContactNo);

        header.setText("Thanks for applying, " + extras.getString("firstName") + "!");
        expression.setImageResource(isApproved ? TAKAMAKI_APPROVED : TAKAMAKI_WAITLISTED);
        verdict.setText(isApproved ? "You Qualify!" : "I will get in touch with your contact no.");
        height.setText("Your height: " + extras.getString("height") + " cm");
        weight.setText("Your weight: " + extras.getString("weight") + " kg");
        gender.setText("Your gender: " + extras.getString("gender"));
        bmiOrContactNo.setText(isApproved ? "Calculated BMI: " + extras.getFloat("bmi") :
                "Your contact no.: " + extras.getString("contactNo"));
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}