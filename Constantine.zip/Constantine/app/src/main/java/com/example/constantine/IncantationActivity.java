package com.example.constantine;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class IncantationActivity extends AppCompatActivity {

    private String exString = "Maleficto Exorcismo";
    private String prString = "Purifasto Leveno";

    private String csString = "Finit Cruciolo";

    private TextView incantationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incantation);
        incantationView = (TextView) findViewById(R.id.incText);
    }

    public void exorcism(View v)
    {
        incantationView.setText(exString);
    }

    public void purification(View v)
    {
        incantationView.setText(prString);
    }

    public void curse(View v)
    {
        incantationView.setText(csString);
    }
}