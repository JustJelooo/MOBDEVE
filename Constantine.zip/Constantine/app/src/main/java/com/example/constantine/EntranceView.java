package com.example.constantine;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

public class EntranceView extends SurfaceView implements SurfaceHolder.Callback{

    private SurfaceHolder surfaceHolder = null;
    private Context activityContext;

    public EntranceView(Context context) {
        super(context);

        if(surfaceHolder == null) {
            surfaceHolder = getHolder();
            surfaceHolder.addCallback(this);
        }

        this.activityContext = context;
        this.setBackgroundColor(Color.BLACK);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Bitmap icon = BitmapFactory.decodeResource(getResources(),R.drawable.icon);
        icon = Bitmap.createScaledBitmap(icon, 900, 900, false);
        canvas.drawColor(Color.BLACK);
        canvas.drawBitmap(icon, 80, 600, new Paint());
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {
        Canvas canvas = null;
        try {
            canvas = surfaceHolder.lockCanvas(null);
            synchronized (surfaceHolder) {
                draw(canvas);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (canvas != null) {
                surfaceHolder.unlockCanvasAndPost(canvas);
            }
        }
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {

    }

    // TODO: Add the method which will allow you to progress to MenuActivity after a touch is detected

    /*
    HINTS:
        onTouchEvent(MotionEvent event) -> For touches
        MotionEvent.ACTION_DOWN -> Tap

        Use:
        activityContext & Intent's setFlags(Intent.FLAG_ACTIVITY_NEW_TASK) method to start a new intent
     */
}
